<?xml version='1.0' encoding='utf-8'?>
<!-- ident   "%Z%%M% %I%   %E% SMI" -->
<!DOCTYPE helpset PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 2.0//EN" "helpset_1_0.dtd">

<helpset version="2.0" xml:lang="en">
<title>SAM&#8212;QFS Manager User's Guide</title>
<maps>
	<homeID></homeID>
	<mapref location="map.jhm"/>
</maps>
<view>
	<name>TOC</name>
	<label>Contents</label>
	<type>javax.help.TOCView</type>
	<data>toc.xml</data>
</view>
<view>
	<name>Index</name>
	<label>Index</label>
	<type>javax.help.IndexView</type>
	<data>index.xml</data>
</view>
<view>
	<name>Search</name>
	<label>Search</label>
	<type>javax.help.SearchView</type>
	<data engine="com.sun.java.help.search.DefaultSearchEngine">JavaHelpSearch</data>
</view>
</helpset>
